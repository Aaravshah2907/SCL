% Utility to open the timestable app for editing.

%   Copyright 2018 MathWorks, Inc.

edit('timestable.mlapp')

