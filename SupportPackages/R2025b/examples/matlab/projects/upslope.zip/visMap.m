% visMap  Visualize influence map, dependence map, or upslope area on a DEM
%
% DESCRIPTION
% visMap(M, E) displays an influence map, dependence map, or upslope area
% matrix M by superimposing it on a DEM matrix E.
%
% visMap(M, E, BW) displays an influence or dependence map M superimposed on
% a DEM image E.  BW is a binary image specifying the starting or ending DEM
% locations for the influence or dependence map, respectively.  Starting or
% ending pixel locations are shown in blue, and pixels with nonzero influence or
% dependence values are shown in transparent green.
%
% visMap(M, E, i, j) uses vectors i and j as row and column coordinates
% for the starting DEM locations.
%
% EXAMPLE
%     E = peaks;
%     R = demFlow(E);
%     T = flowMatrix(E, R);
%     D = dependenceMap(E, T, 12, 24);
%     visMap(D, E, 12, 24)
%
% See also dependenceMap, influenceMap, upslopeArea.

% Steven L. Eddins
% Copyright 2007-2009 The MathWorks, Inc.

function visMap(M, E, arg3, arg4)

requiresIPT(mfilename);

if nargin < 3
    BW = false(size(M));

elseif nargin < 4
    BW = arg3;
    
else
    i = arg3;
    j = arg4;
    BW = false(size(M));
    BW((j - 1)*size(M,1) + i) = true;
end

% Make and display an RGB image that is the autoscaled E matrix with the
% starting pixel locations shown in a shade of blue.
source_color = im2uint8([.5 .5 1]);
E = im2uint8(mat2gray(E));
red = E;
green = E;
blue = E;
red(BW) = source_color(1);
green(BW) = source_color(2);
blue(BW) = source_color(3);
rgb_bottom = cat(3, red, green, blue);
imshow(rgb_bottom, 'InitialMag', 'fit')

% Make a second RGB image that is a constant green.
rgb_top = zeros(size(M,1), size(M,2), 3, 'uint8');
rgb_top(:,:,2) = 255;

% Turn the influence or dependence map into an AlphaData channel to be used
% to display with the green image.
M(BW) = 0;
M = imadjust(mat2gray(M), [0 1], [0 .6], 0.5);

image('CData', rgb_top, 'AlphaData', M);
hold off
