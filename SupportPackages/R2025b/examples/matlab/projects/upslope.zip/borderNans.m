% borderNans Find NaNs connected to the DEM border
%
% DESCRIPTION
% mask = borderNans(E) finds all connected NaN components that touch the border
% of E, the digital elevation model (DEM). mask is a logical matrix the same
% size as E.  True values in mask correspond to border NaN locations. 
%
% EXAMPLE
%     E = magic(5);
%     E(2:5,1:2) = NaN;
%     E(3:4,4) = NaN
%     borderNans(E)
%
% See also pixelFlow, upslopeArea.

% Steven L. Eddins
% Copyright 2007-2009 The MathWorks, Inc.

function mask = borderNans(E)

requiresIPT(mfilename);

nan_mask = isnan(E);
mask = nan_mask & ~imclearborder(nan_mask);
