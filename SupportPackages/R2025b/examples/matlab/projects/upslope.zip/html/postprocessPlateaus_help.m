%% postprocessPlateaus
% Replace upslope areas for plateaus with mean value 
%
%% Description
% |Ap = postprocessPlateaus(A, E)| "flattens" the upslope area computation for
% plateaus in a DEM.  |A| is the upslope area for the DEM |E|, as computed by
% |upslopeArea|.  |Ap| is the same as |A|, except that the upslope area values for
% each plateau are replace by the mean value for that plateau.
%
%% Example
%
s = load('milford_ma_dem');
E = s.Zc;
R = demFlow(E);
T = flowMatrix(E, R);
A = upslopeArea(E, T);
Ap = postprocessPlateaus(A, E);
subplot(1,2,1)
imshow(log(A), [])
title('Upslope Area')
subplot(1,2,2)
imshow(log(Ap), [])
title('Upslope Area - Postprocessed')

%% See also
% <upslopeArea_help.html |upslopeArea|>.

%% 
% Copyright 2007-2009 The MathWorks, Inc.