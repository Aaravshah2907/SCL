% fillSinks Fill interior sinks in DEM
%
% DESCRIPTION
% Ef = fillSinks(E) fills interior sinks in a DEM.
%
% EXAMPLE
%     s = load('milford_ma_dem');
%     E = s.Zc;
%     Ef = fillSinks(E);
%     R = demFlow(Ef);
%     T = flowMatrix(Ef, R);
%     A = upslopeArea(Ef, T);
%     imshow(log(A), [])
%
% See also imfill, upslopeArea.

% Steven L. Eddins
% Copyright 2007-2009 The MathWorks, Inc.

function Ef = fillSinks(E)

requiresIPT(mfilename);

border_nan_mask = borderNans(E);
E(border_nan_mask) = -Inf;

Ef = imfill(E, 8, 'holes');
Ef(border_nan_mask) = NaN;
