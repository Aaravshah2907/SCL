% requiresIPT Errors if Image Processing Toolbox is not present
%
% DESCRIPTION
% requiresIPT(function_name) issues an error message if the Image Processing
% Toolbox is not present.  The error message takes the form:
%
%     Function _function_name_ requires the Image Processing Toolbox.
%
% EXAMPLE
%     requiresIPT('borderNans')
%
% See also verLessThan.

% Steven L. Eddins
% Copyright 2009 The MathWorks, Inc.

function requiresIPT(function_name)

toolbox_present = false;

try
    toolbox_present = ~verLessThan('images', '4.0');
end

if ~toolbox_present
    id = sprintf('Upslope:%s:noIPT', function_name);
    error(id, 'Function %s requires the Image Processing Toolbox.', ...
        function_name);
end